HTTP/1.1 200 OK
Content-Security-Policy: default-src 'self';base-uri 'self';font-src 'self' https: data:;form-action 'self';frame-ancestors 'self';img-src 'self' data:;object-src 'none';script-src 'self';script-src-attr 'none';style-src 'self' https: 'unsafe-inline';upgrade-insecure-requests
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
Origin-Agent-Cluster: ?1
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Content-Type-Options: nosniff
X-DNS-Prefetch-Control: off
X-Download-Options: noopen
X-Frame-Options: SAMEORIGIN
X-Permitted-Cross-Domain-Policies: none
X-XSS-Protection: 0
content-type: application/json
cache-control: no-cache
vary: If-None-Match
etag: "ffa962ca91a3383ec5d4bec8c484674b93b8f8c36be8911a394805bc46b2d1b4"
content-length: 808
x-request-id: req-11dv
Date: Tue, 30 Sep 2025 12:45:52 GMT
Connection: keep-alive
Keep-Alive: timeout=72

